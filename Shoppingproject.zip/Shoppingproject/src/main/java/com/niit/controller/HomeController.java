package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.model.User;
import com.niit.service.Loginservice;

@Controller
public class HomeController {
	
	

	@Autowired
	Loginservice ls;
	
	@RequestMapping("/")
	private String initial()
	{
		return "latestbike";
	}
	@RequestMapping("/home")
	public String getHome()
	{
		return "home";
	
	}
	
	@RequestMapping("/login")
	private String fun()
	{
		return "login";
	}
	@RequestMapping("/Suzuki")
	private String demo()
	{
		return "Suzuki";
	}
	
	
	@RequestMapping("/Bajaj")
	private String sample()
	{
		return "Bajaj";
	}
	@RequestMapping("/Bajaj pulsar")
	private String model()
	{
		return "Bajaj pulsar";
	}
	@RequestMapping("/Mahindra")
	private String dull()
	{
		return "Mahindra";
	}
	
	@RequestMapping("/Honda")
	private String honda()
	{
		return "Honda";
	}
	@RequestMapping("/Hero")
	private String hero()
	{
		return "Hero";
	}
	@RequestMapping("/Bajaj discover")
	private String bajaj()
	{
		return "Bajaj discover";
	}
	@RequestMapping("/Mahindra centuro")
	private String ceturo()
	{
		return "Mahindra centuro";
	}
	
	@RequestMapping("/logo")
	private String latest()
	{
		return "logo";
	}
	
	@RequestMapping(value="/link",method=RequestMethod.POST)
	public ModelAndView loginuser(@RequestParam("name") String name,@RequestParam("pwd") String pwd){
		boolean isvaliduser =false;
		User u=new User();
		u.setName(name);
		u.setPassword(pwd);
		isvaliduser =ls.CheckUser(u);
		ModelAndView mv=new ModelAndView("latestbike");
		if(isvaliduser==true)
		{
		mv.addObject("msg", "hello welcome");
		mv.addObject("name", u.getName());
		}
		return mv;
	}

}
