package com.niit.model;

import java.beans.Transient;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

public class UploadForm {

	private String name ;
	private CommonsMultipartFile file;
	@Transient
	public String getName() {
		return name;
	}
	@Transient
	public void setName(String name) {
		this.name = name;
	}
	@Transient
	public CommonsMultipartFile getFile() {
		return file;
	}
	@Transient
	public void setFile(CommonsMultipartFile file) {
		this.file = file;
	}
	
}
