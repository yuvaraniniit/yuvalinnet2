package com.niit.service;

import java.util.List;

import com.niit.model.Product;

public interface Productservice {

	
	public void add(Product product);
	public void edit(Product product);
	public void delete(String productId);
	public Product getProduct(String productId);
	public List getAllProduct();
}
