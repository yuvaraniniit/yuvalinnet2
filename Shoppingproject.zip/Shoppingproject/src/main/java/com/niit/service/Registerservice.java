package com.niit.service;

import com.niit.model.Register;

public interface Registerservice {

	public boolean save(Register ob);

	public void edit(Register ob);
	
}
