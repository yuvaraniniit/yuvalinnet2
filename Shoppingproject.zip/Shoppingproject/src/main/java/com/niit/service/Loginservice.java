package com.niit.service;

import com.niit.model.User;

public interface Loginservice {
	
	public boolean CheckUser(User u);

}
