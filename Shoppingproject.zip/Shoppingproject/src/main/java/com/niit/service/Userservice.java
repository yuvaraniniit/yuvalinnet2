package com.niit.service;

public interface Userservice {

}
