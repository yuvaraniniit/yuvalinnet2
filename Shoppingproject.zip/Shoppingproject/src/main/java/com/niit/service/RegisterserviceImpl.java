package com.niit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.dao.RegisterDAO;
import com.niit.model.Register;


@Service
@Transactional
public class RegisterserviceImpl implements Registerservice {
	
	@Autowired
	private RegisterDAO dao;
	
	
	@Override
	public boolean save(Register ob)
	{
		dao.save(ob);
		return false;
	}
	
	public void edit(Register ob){
		dao.edit(ob);
	}
	
}
