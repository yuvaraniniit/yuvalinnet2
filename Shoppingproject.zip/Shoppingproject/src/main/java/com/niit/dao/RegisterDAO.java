package com.niit.dao;

import org.springframework.stereotype.Repository;

import com.niit.model.Register;

@Repository
public interface RegisterDAO {
	
public boolean save(Register ob);

	public void edit(Register ob);

}
