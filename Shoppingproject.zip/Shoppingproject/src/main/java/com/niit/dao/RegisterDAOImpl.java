package com.niit.dao;

import java.io.Serializable;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Register;

@Repository
public class RegisterDAOImpl implements RegisterDAO {

	@Autowired
	private SessionFactory sf;
	
	@Override
	@Transactional
	public boolean save(Register ob){
	
	Serializable o=sf.getCurrentSession().save(ob);
	if(o.equals(null) || o==null)
		return true;
	else
		return false;
}

    public void edit(Register ob){
    	((RegisterDAOImpl) sf.getCurrentSession()).edit(ob);
    	
    }
    	
   }
