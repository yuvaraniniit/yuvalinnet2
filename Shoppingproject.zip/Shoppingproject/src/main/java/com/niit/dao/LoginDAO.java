package com.niit.dao;

import com.niit.model.User;

public interface LoginDAO {
	

	public boolean CheckUser(User u);
	

}
