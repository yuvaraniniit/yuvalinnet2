package com.niit.dao;

import java.util.List;

import javax.persistence.AssociationOverride;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Product;

@Repository
@Transactional
public class ProductDAOImpl implements ProductDAO
{
	@Autowired(required=true)
	private SessionFactory session;
	
	@Override
   public void add(Product product ){
	   session.getCurrentSession().save(product);
   }
	
	@Override
   public void edit(Product product){
       session.getCurrentSession().update(product);
   }
   
	@Override
	public void delete(String getId){
		session.getCurrentSession().delete(getProduct(getId));
	}
		@Override
		public Product getProduct(String getId){
			return (Product)session.getCurrentSession().get(Product.class,getId);
		}
		
		@Override
		public List getAllProduct(){
			return session.getCurrentSession().createQuery("from Product").list();
		}
	}
   

