package com.niit.dao;

import java.util.List;

import com.niit.model.Product;

public interface ProductDAO {

  public void add(Product product);
  public void edit(Product product);
  public void delete(String getId);
  public Product getProduct(String getId);
  public List getAllProduct();
}
