/*package com.niit.shop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shop.dao.LoginDAO;
import com.niit.shop.model.User;


@Service
@Transactional
public class LoginServiceImpl implements LoginService {

	

	@Autowired(required=true)
	private LoginDAO ld;
	
	public boolean CheckUser(User u) {
		boolean b=false;
		b=ld.CheckUser(u);
		if(b==true){
			b=true;
		}
		return b;
	}
}

*/