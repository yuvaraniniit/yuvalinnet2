/*package com.niit.shop.dao;

import org.springframework.stereotype.Repository;

import com.niit.shop.model.Register;

@Repository
public interface RegisterDAO {
	
public boolean save(Register ob);

	public void edit(Register ob);

}
*/