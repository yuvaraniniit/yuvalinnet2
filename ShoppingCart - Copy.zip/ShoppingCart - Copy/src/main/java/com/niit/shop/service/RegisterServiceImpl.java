/*package com.niit.shop.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.shop.dao.RegisterDAO;
import com.niit.shop.model.Register;


@Service
@Transactional
public class RegisterServiceImpl implements RegisterService {
	
	@Autowired
	private RegisterDAO dao;
	
	
	@Override
	public boolean save(Register ob)
	{
		dao.save(ob);
		return false;
	}
	
	public void edit(Register ob){
		dao.edit(ob);
	}
	
}
*/