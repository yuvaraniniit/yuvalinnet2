package com.niit.shop.service;

public interface CategoryService {

}
