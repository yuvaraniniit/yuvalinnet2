/*package com.niit.shop.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminController {
	

	@ModelAttribute("oc")
	public Category construct(){
		return new Category();
	}
	@Autowired
	private CategoryService categoryservice;
	
	@RequestMapping(value="/category")
	public String prod()
	{
	return "category";	
	}
	
	@RequestMapping(value="/category.do", method=RequestMethod.POST)
	public String doActions(@ModelAttribute("oc") Category category, BindingResult result, @RequestParam String action, Map<String, Object>map){
	    ProductModel productmodelResult = new ProductModel();
	    switch(action.toLowerCase()){
	    case "add":
	    	productservice.add(productModel);
	    	productmodelResult = productModel;
	    	break;
	    	
	    case "edit":
	    	productservice.edit(productModel);
	    	productmodelResult = productModel;
	    	break;
	    	
	    case "delete":
	    	productservice.delete(productModel.getId());
	    	productmodelResult = new ProductModel();
	    	break;
	    	
	    case "search":
	    	ProductModel searchedProductModel = productservice.getProductModel(productModel.getId());
	    	productmodelResult = searchedProductModel!=null ? searchedProductModel : new ProductModel();
	    	break;
	    }
	    map.put("productModel",productmodelResult);
	    map.put("productmodelList", productservice.getAllProductModel());
	    
		return "product";
	}

}
*/