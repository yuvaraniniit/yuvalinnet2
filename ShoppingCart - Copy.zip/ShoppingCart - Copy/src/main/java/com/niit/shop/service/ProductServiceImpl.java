package com.niit.shop.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shop.dao.ProductDAO;
import com.niit.shop.model.Product;


@Service("productService")
@Transactional(propagation = Propagation.SUPPORTS)
public class ProductServiceImpl implements ProductService{
	
	@Autowired(required=true)
	private ProductDAO productDAO;

	public int insertRow(Product prod,String s) {
		// TODO Auto-generated method stub
		return  productDAO.insertRow(prod,s);
		 
	}

	public List getList() {
		// TODO Auto-generated method stub
		return productDAO.getList();
	}

	public Product getRowById(int id) {
		// TODO Auto-generated method stub
		return  productDAO.getRowById(id);
	}

	public int updateRow(Product prod) {
		// TODO Auto-generated method stub
		return  productDAO.updateRow(prod);
	}

	public int deleteRow(int id) {
		// TODO Auto-generated method stub
		return  productDAO.deleteRow(id);
	}
}
