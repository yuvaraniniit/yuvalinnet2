
/*package com.niit.shop.service;

import com.niit.shop.model.User;

public interface LoginService {
	
	public boolean CheckUser(User u);

}
*/