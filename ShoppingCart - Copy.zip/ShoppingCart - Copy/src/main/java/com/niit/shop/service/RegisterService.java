/*package com.niit.shop.service;

import com.niit.shop.model.Register;

public interface RegisterService {

	public boolean save(Register ob);

	public void edit(Register ob);
	
}
*/