/*package com.niit.shop.dao;

import com.niit.shop.model.User;

public interface LoginDAO {
	

	public boolean CheckUser(User u);
	

}
*/
